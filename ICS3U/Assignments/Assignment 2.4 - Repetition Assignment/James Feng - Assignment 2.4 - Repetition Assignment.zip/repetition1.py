# James
# repetition1.py

while True:
    prompt = input("Please enter the correct password >> ")
    # Checking for correct password.
    if prompt == "pythonzen77":
        break
    else:
        print("Incorrect password.")

# Grant access to whatever.
print("Access granted.")